Kraken SDR V2 by Brandonsmith90 on Thingiverse: https://www.thingiverse.com/thing:6960490

Summary:
I made a few modifications for my Bambu Lab P1S