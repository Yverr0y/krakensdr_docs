KrakenSDR DOA Antenna Array Template (150 MHz to 1'766 MHz) Full Arm by TeachMeSomething on Thingiverse: https://www.thingiverse.com/thing:6248487

Summary:
This is a very simple remix of the arm from Thinger13's KrakenSDR DOA Antenna Array Template. I took the two halves of the arm (the arm + extender) and connected them for anyone printing on a larger bed like myself.